package com.promptpro.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.IBinder
import android.util.TypedValue
import android.view.Choreographer
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import kotlin.math.max

/**
 * Floating teleprompter: a small window that stays on top of other apps
 * (camera, social media, live streams). Drag it from the dots at the top,
 * resize it from the corner handle at the bottom right.
 */
class FloatingService : Service() {

    private lateinit var wm: WindowManager
    private var root: FrameLayout? = null
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var sv: ScrollView
    private lateinit var tv: TextView
    private lateinit var playBtn: TextView
    private lateinit var speedLabel: TextView
    private lateinit var bottomBar: LinearLayout
    private lateinit var resizeHandle: TextView

    private var session: MediaSession? = null
    private var map: HashMap<Int, String> = HashMap()
    private var markers: List<Int> = emptyList()

    private var running = false
    private var speed = 326f
    private var fontSp = 22f
    private var stepAmount = 60f
    private var accum = 0f
    private var lastFrame = 0L
    private var collapsed = false
    private var expandedHeight = 0

    private val frame = object : Choreographer.FrameCallback {

        override fun doFrame(frameTimeNanos: Long) {

            if (!running) {
                lastFrame = 0L
                return
            }

            if (lastFrame != 0L) {

                val dt = ((frameTimeNanos - lastFrame) / 1_000_000_000f)
                    .coerceAtMost(0.05f)

                val textH = (tv.layout?.height ?: tv.height).toFloat()
                val pxPerChar = textH / max(1, tv.text.length)

                accum += speed / 60f * pxPerChar * dt

                val whole = accum.toInt()

                if (whole != 0) {
                    sv.scrollBy(0, whole)
                    accum -= whole
                }

                val child = sv.getChildAt(0)

                if (
                    child != null &&
                    sv.scrollY + sv.height >= child.height - 1
                ) {
                    running = false
                    lastFrame = 0L
                    updatePlayLabel()
                    return
                }
            }

            lastFrame = frameTimeNanos
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun dp(v: Float): Float =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics
        )

    private fun dpi(v: Float): Int = dp(v).toInt()

    private fun prefs() = getSharedPreferences("pp", Context.MODE_PRIVATE)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        startForeground(1, buildNotification())

        val text = intent?.getStringExtra("text") ?: ""

        if (root == null) {
            createOverlay(text)
        } else {
            applyText(text)
        }

        startSession()

        return START_NOT_STICKY
    }

    override fun onDestroy() {

        running = false
        Choreographer.getInstance().removeFrameCallback(frame)

        try {
            val r = root
            if (r != null && ::wm.isInitialized) {
                wm.removeView(r)
            }
        } catch (_: Throwable) {
        }
        root = null

        try {
            session?.isActive = false
            session?.release()
        } catch (_: Throwable) {
        }
        session = null

        super.onDestroy()
    }

    private fun buildNotification(): Notification {

        val nm = getSystemService(NotificationManager::class.java)

        nm.createNotificationChannel(
            NotificationChannel(
                "float",
                "Floating teleprompter",
                NotificationManager.IMPORTANCE_LOW
            )
        )

        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE
        )

        return Notification.Builder(this, "float")
            .setContentTitle("PromptPro floating teleprompter")
            .setContentText("Chal raha hai - app kholne ke liye tap karo")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
    }

    private fun applyText(raw: String) {
        val parsed = parseScript(raw)
        markers = parsed.second
        tv.text = parsed.first
        sv.scrollTo(0, 0)
        setRunning(false)
    }

    private fun makeButton(
        label: String,
        sizeSp: Float,
        onClick: () -> Unit
    ): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
        t.gravity = Gravity.CENTER
        t.setOnClickListener { onClick() }
        return t
    }

    private fun createOverlay(raw: String) {

        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        val pr = prefs()

        speed = pr.getFloat("ov_speed", pr.getFloat("speed", 326f))
        fontSp = pr.getFloat("ov_font", 22f)
        stepAmount = pr.getFloat("remoteStep", 60f)
        map = RemoteMap.build(pr)

        val parsed = parseScript(raw)
        markers = parsed.second

        val dm = resources.displayMetrics

        val w = pr.getInt("ov_w", (dm.widthPixels * 0.88f).toInt())
        val h = pr.getInt("ov_h", dpi(320f))

        lp = WindowManager.LayoutParams(
            w,
            h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = pr.getInt("ov_x", dpi(12f))
        lp.y = pr.getInt("ov_y", dpi(120f))

        val bg = GradientDrawable()
        bg.setColor(Color.parseColor("#E61C1C1E"))
        bg.cornerRadius = dp(20f)

        val r = FrameLayout(this)
        r.background = bg

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        r.addView(
            col,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        // ---- Top bar: open app | drag handle | collapse | close ----

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL

        val gear = makeButton("⚙", 18f) {
            try {
                startActivity(
                    Intent(this, MainActivity::class.java).addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                    )
                )
            } catch (_: Throwable) {
            }
        }

        val drag = TextView(this)
        drag.text = "• • • • •"
        drag.setTextColor(Color.parseColor("#9A9A9A"))
        drag.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        drag.gravity = Gravity.CENTER

        drag.setOnTouchListener(object : View.OnTouchListener {

            var sx = 0
            var sy = 0
            var tx = 0f
            var ty = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x
                        sy = lp.y
                        tx = e.rawX
                        ty = e.rawY
                    }

                    MotionEvent.ACTION_MOVE -> {
                        lp.x = sx + (e.rawX - tx).toInt()
                        lp.y = sy + (e.rawY - ty).toInt()
                        relayout()
                    }

                    MotionEvent.ACTION_UP -> savePos()
                }
                return true
            }
        })

        val collapse = makeButton("−", 22f) { toggleCollapse() }

        val close = makeButton("✕", 18f) { stopSelf() }

        top.addView(gear, LinearLayout.LayoutParams(dpi(44f), dpi(42f)))
        top.addView(drag, LinearLayout.LayoutParams(0, dpi(42f), 1f))
        top.addView(collapse, LinearLayout.LayoutParams(dpi(44f), dpi(42f)))
        top.addView(close, LinearLayout.LayoutParams(dpi(44f), dpi(42f)))

        col.addView(
            top,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpi(42f)
            )
        )

        // ---- Script text ----

        sv = ScrollView(this)
        sv.isVerticalScrollBarEnabled = false

        tv = TextView(this)
        tv.text = parsed.first
        tv.setTextColor(Color.WHITE)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp)
        tv.setLineSpacing(0f, 1.25f)
        tv.setPadding(dpi(14f), dpi(6f), dpi(14f), dpi(160f))

        sv.addView(
            tv,
            ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        col.addView(sv, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))

        // ---- Bottom bar: font - + | speed - label + | play | reset ----

        bottomBar = LinearLayout(this)
        bottomBar.orientation = LinearLayout.HORIZONTAL
        bottomBar.gravity = Gravity.CENTER_VERTICAL
        bottomBar.setPadding(dpi(6f), 0, dpi(38f), 0)

        speedLabel = TextView(this)
        speedLabel.setTextColor(Color.parseColor("#FFCC99"))
        speedLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        speedLabel.gravity = Gravity.CENTER
        updateSpeedLabel()

        playBtn = makeButton("▶", 22f) { toggle() }

        val items = listOf<View>(
            makeButton("A−", 15f) { changeFont(-2f) },
            makeButton("A+", 15f) { changeFont(2f) },
            makeButton("−", 22f) { changeSpeed(-20f) },
            speedLabel,
            makeButton("+", 22f) { changeSpeed(20f) },
            playBtn,
            makeButton("↺", 20f) { reset() }
        )

        for (v in items) {
            bottomBar.addView(
                v,
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f)
            )
        }

        col.addView(
            bottomBar,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpi(44f)
            )
        )

        // ---- Resize handle (bottom right corner) ----

        resizeHandle = TextView(this)
        resizeHandle.text = "◢"
        resizeHandle.setTextColor(Color.parseColor("#BBBBBB"))
        resizeHandle.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
        resizeHandle.gravity = Gravity.CENTER

        resizeHandle.setOnTouchListener(object : View.OnTouchListener {

            var sw = 0
            var sh = 0
            var tx = 0f
            var ty = 0f

            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sw = lp.width
                        sh = lp.height
                        tx = e.rawX
                        ty = e.rawY
                    }

                    MotionEvent.ACTION_MOVE -> {
                        lp.width = (sw + (e.rawX - tx).toInt())
                            .coerceIn(dpi(200f), dm.widthPixels)
                        lp.height = (sh + (e.rawY - ty).toInt())
                            .coerceIn(dpi(150f), dm.heightPixels)
                        relayout()
                    }

                    MotionEvent.ACTION_UP -> savePos()
                }
                return true
            }
        })

        r.addView(
            resizeHandle,
            FrameLayout.LayoutParams(
                dpi(40f),
                dpi(40f),
                Gravity.BOTTOM or Gravity.END
            )
        )

        root = r
        wm.addView(r, lp)
    }

    private fun relayout() {
        val r = root ?: return
        try {
            wm.updateViewLayout(r, lp)
        } catch (_: Throwable) {
        }
    }

    private fun savePos() {
        val e = prefs().edit()
        e.putInt("ov_x", lp.x)
        e.putInt("ov_y", lp.y)
        e.putInt("ov_w", lp.width)
        if (!collapsed) {
            e.putInt("ov_h", lp.height)
        }
        e.apply()
    }

    private fun toggleCollapse() {

        collapsed = !collapsed

        if (collapsed) {
            setRunning(false)
            expandedHeight = lp.height
            sv.visibility = View.GONE
            bottomBar.visibility = View.GONE
            resizeHandle.visibility = View.GONE
            lp.height = dpi(42f)
        } else {
            sv.visibility = View.VISIBLE
            bottomBar.visibility = View.VISIBLE
            resizeHandle.visibility = View.VISIBLE
            lp.height = if (expandedHeight > 0) expandedHeight else dpi(320f)
        }

        relayout()
    }

    // ---- Playback and controls ----

    private fun updatePlayLabel() {
        playBtn.text = if (running) "❚❚" else "▶"
    }

    private fun updateSpeedLabel() {
        speedLabel.text = speed.toInt().toString()
    }

    private fun setRunning(on: Boolean) {

        running = on
        updatePlayLabel()

        Choreographer.getInstance().removeFrameCallback(frame)

        if (on) {
            lastFrame = 0L
            accum = 0f
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun toggle() {

        if (running) {
            setRunning(false)
            return
        }

        val child = sv.getChildAt(0)

        if (
            child != null &&
            sv.scrollY + sv.height >= child.height - 1
        ) {
            sv.scrollTo(0, 0)
        }

        setRunning(true)
    }

    private fun reset() {
        setRunning(false)
        sv.scrollTo(0, 0)
    }

    private fun changeSpeed(delta: Float) {
        speed = (speed + delta).coerceIn(60f, 900f)
        updateSpeedLabel()
        prefs().edit().putFloat("ov_speed", speed).apply()
    }

    private fun changeFont(delta: Float) {
        fontSp = (fontSp + delta).coerceIn(12f, 60f)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, fontSp)
        prefs().edit().putFloat("ov_font", fontSp).apply()
    }

    private fun nudge(dir: Int) {
        sv.smoothScrollBy(0, dpi(stepAmount * 3f) * dir)
    }

    private fun paragraph(dir: Int) {

        val layout = tv.layout ?: return

        val ys = markers.map {
            layout.getLineTop(
                layout.getLineForOffset(it.coerceIn(0, tv.text.length))
            ) + tv.paddingTop
        }

        val cur = sv.scrollY

        val target: Int? =
            if (dir > 0) {
                ys.firstOrNull { it > cur + 8 }
            } else {
                ys.lastOrNull { it < cur - 8 } ?: 0
            }

        if (target != null) {
            sv.smoothScrollTo(0, target)
        }
    }

    private fun act(a: String) {
        when (a) {
            "PAUSE" -> toggle()
            "UP" -> nudge(-1)
            "DOWN" -> nudge(1)
            "SPEED_UP" -> changeSpeed(20f)
            "SPEED_DOWN" -> changeSpeed(-20f)
            "FONT_UP" -> changeFont(2f)
            "FONT_DOWN" -> changeFont(-2f)
            "NEXT_PARA" -> paragraph(1)
            "PREV_PARA" -> paragraph(-1)
            "RESET" -> reset()
        }
    }

    // ---- Bluetooth remote (media buttons) ----

    private fun startSession() {

        if (session != null) return

        try {
            val ms = MediaSession(this, "PromptProFloat")

            ms.setCallback(object : MediaSession.Callback() {
                override fun onMediaButtonEvent(
                    mediaButtonIntent: Intent
                ): Boolean {
                    @Suppress("DEPRECATION")
                    val ke = mediaButtonIntent
                        .getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)

                    if (
                        ke != null &&
                        ke.action == KeyEvent.ACTION_DOWN &&
                        ke.repeatCount == 0
                    ) {
                        val a = map[ke.keyCode]
                        if (a != null) act(a)
                    }
                    return true
                }
            })

            ms.setPlaybackState(
                PlaybackState.Builder()
                    .setActions(
                        PlaybackState.ACTION_PLAY or
                            PlaybackState.ACTION_PAUSE or
                            PlaybackState.ACTION_PLAY_PAUSE or
                            PlaybackState.ACTION_SKIP_TO_NEXT or
                            PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                            PlaybackState.ACTION_STOP
                    )
                    .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                    .build()
            )

            ms.isActive = true
            session = ms

        } catch (_: Throwable) {
        }
    }
}
