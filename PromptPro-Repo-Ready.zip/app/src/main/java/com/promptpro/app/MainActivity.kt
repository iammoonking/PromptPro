
package com.promptpro.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.view.video.AudioConfig
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.sqrt

private val bg = Color(0xFF090909)
private val panel = Color(0xFF171717)
private val gold = Color(0xFFD8B45A)
private val cream = Color(0xFFF4EBD7)

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = gold,
                    background = bg,
                    surface = panel,
                    onSurface = cream,
                    onBackground = cream
                )
            ) {
                PromptPro {
                    perms.launch(
                        arrayOf(
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO
                        )
                    )
                }
            }
        }
    }
}

private fun displayName(c: Context, uri: Uri): String {
    var name = "Imported script.txt"
    c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) {
            name = cur.getString(i) ?: name
        }
    }
    return name
}

private fun extractText(c: Context, uri: Uri, ext: String): String {
    return when (ext) {
        "docx" -> docxText(c, uri)
        "pdf" -> pdfText(c, uri)
        else -> c.contentResolver.openInputStream(uri)!!
            .bufferedReader().use { it.readText() }
    }
}

private fun docxText(c: Context, uri: Uri): String {
    c.contentResolver.openInputStream(uri)!!.use { ins ->
        java.util.zip.ZipInputStream(ins).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    return xmlToText(xml)
                }
                e = zip.nextEntry
            }
        }
    }
    return ""
}

private fun xmlToText(xml: String): String {
    return xml
        .replace("</w:p>", "\n")
        .replace(Regex("<w:br[^>]*/>"), "\n")
        .replace(Regex("<w:tab[^>]*/>"), "\t")
        .replace(Regex("<[^>]+>"), "")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
}

private fun pdfText(c: Context, uri: Uri): String {
    com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(c.applicationContext)
    return c.contentResolver.openInputStream(uri)!!.use { ins ->
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(ins).use { doc ->
            com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc)
        }
    }.trim()
}

private fun granted(c: Context, p: String): Boolean {
    return ContextCompat.checkSelfPermission(
        c, p
    ) == PackageManager.PERMISSION_GRANTED
}

private fun readScripts(c: Context): LinkedHashMap<String, String> {

    val raw = c.getSharedPreferences("pp", 0)
        .getString("scripts", null)
        ?: return linkedMapOf(
            "My first script" to
                "Namaskar dosto! Apni script yahan likhein."
        )

    return try {
        val j = JSONObject(raw)
        LinkedHashMap<String, String>().apply {
            j.keys().forEach { k ->
                put(k, j.optString(k))
            }
        }
    } catch (_: Exception) {
        linkedMapOf("My first script" to "")
    }
}

private fun writeScripts(
    c: Context,
    m: Map<String, String>
) {
    val j = JSONObject()
    m.forEach { (k, v) -> j.put(k, v) }

    c.getSharedPreferences("pp", 0)
        .edit()
        .putString("scripts", j.toString())
        .apply()
}

@Composable
fun PromptPro(requestPermissions: () -> Unit) {

    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current

    var library by remember {
        mutableStateOf(readScripts(ctx))
    }

    var selected by remember {
        mutableStateOf(library.keys.first())
    }

    var script by remember {
        mutableStateOf(library[selected] ?: "")
    }

    var newName by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf(false) }
    var showLibrary by remember { mutableStateOf(false) }

    var camera by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var recording by remember { mutableStateOf(false) }

    var activeRecording by remember {
        mutableStateOf<Recording?>(null)
    }

    var running by remember { mutableStateOf(false) }
    var voiceMode by remember { mutableStateOf(true) }
    var voice by remember { mutableStateOf(false) }

    var sensitivity by remember { mutableFloatStateOf(.55f) }
    var speed by remember { mutableFloatStateOf(42f) }
    var font by remember { mutableFloatStateOf(30f) }

    var status by remember { mutableStateOf("Ready") }

    val scroll = rememberScrollState()

    val cam = remember(ctx) {
        LifecycleCameraController(ctx).apply {
            setEnabledUseCases(CameraController.VIDEO_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
        }
    }

    DisposableEffect(cam, owner, camera) {
        if (camera && granted(ctx, Manifest.permission.CAMERA)) {
            try {
                cam.bindToLifecycle(owner)
            } catch (_: Throwable) {
            }
        }
        onDispose {
            activeRecording?.stop()
            try {
                cam.unbind()
            } catch (_: Throwable) {
            }
        }
    }

    val scope = rememberCoroutineScope()

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) { displayName(ctx, uri) }
                val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
                if (ext != "pdf" && ext != "docx" && ext != "txt") {
                    Toast.makeText(
                        ctx, "Sirf PDF, DOCX ya TXT file chuno",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    status = "Importing..."
                    val text = withContext(Dispatchers.IO) {
                        try {
                            extractText(ctx, uri, ext)
                        } catch (e: Throwable) {
                            null
                        }
                    }
                    status = "Ready"
                    if (text == null) {
                        Toast.makeText(
                            ctx, "File padh nahi paya", Toast.LENGTH_LONG
                        ).show()
                    } else if (text.isBlank()) {
                        Toast.makeText(
                            ctx,
                            "File me text nahi mila (scanned PDF ho sakti hai)",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        val base = name.substringBeforeLast('.')
                            .ifBlank { "Imported" }
                        var key = base
                        var n = 2
                        while (library.containsKey(key)) {
                            key = "$base ($n)"
                            n++
                        }
                        library = LinkedHashMap(library).apply {
                            put(selected, script)
                            put(key, text)
                        }
                        writeScripts(ctx, library)
                        selected = key
                        script = text
                        editor = true
                        showLibrary = false
                        Toast.makeText(
                            ctx, "Imported: $key", Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    fun saveCurrent() {
        library = LinkedHashMap(library).apply {
            put(selected, script)
        }
        writeScripts(ctx, library)
        Toast.makeText(
            ctx, "Script saved", Toast.LENGTH_SHORT
        ).show()
    }

    // Voice detection: 1.5 second silence pause

    LaunchedEffect(running, voiceMode, sensitivity) {

        if (
            !running ||
            !voiceMode ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            voice = false
            return@LaunchedEffect
        }

        withContext(Dispatchers.IO) {

            var rec: AudioRecord? = null

            try {

                val rate = 16000

                val size = AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    size * 2
                )
                rec = r

                if (r.state != AudioRecord.STATE_INITIALIZED) {
                    status = "Microphone unavailable"
                    return@withContext
                }

                val buf = ShortArray(1024)
                var floor = -60.0
                var last = 0L
                var lastShown = 0L

                r.startRecording()

                while (isActive && running) {

                    val n = r.read(buf, 0, buf.size)

                    if (n <= 0) {
                        delay(20)
                        continue
                    }

                    var sum = 0.0

                    for (i in 0 until n) {
                        val x = buf[i].toDouble() / 32768.0
                        sum += x * x
                    }

                    val db = 20 * log10(
                        sqrt(sum / n).coerceAtLeast(.000001)
                    )

                    val threshold = maxOf(
                        -52.0 + (1 - sensitivity.toDouble()) * 10,
                        floor + 8 + (1 - sensitivity.toDouble()) * 6
                    )

                    val now = System.currentTimeMillis()

                    if (db > threshold) {
                        last = now
                        voice = true
                    } else {
                        floor = floor * .96 + db * .04

                        if (now - last >= 1500) {
                            voice = false
                        }
                    }

                    if (now - lastShown > 300) {
                        lastShown = now
                        status =
                            (if (voice) "Voice detected · scrolling"
                            else "Paused · waiting for voice") +
                                "  (mic ${db.toInt()} dB, need ${threshold.toInt()} dB)"
                    }

                    delay(20)
                }

            } catch (e: Throwable) {
                if (e is java.util.concurrent.CancellationException) throw e
                status = "Mic error: ${e.localizedMessage}"
                voice = false
            } finally {
                try {
                    rec?.stop()
                } catch (_: Throwable) {
                }
                try {
                    rec?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    // Automatic scrolling

    LaunchedEffect(running, voice, voiceMode, speed) {

        val density = ctx.resources.displayMetrics.density
        var prev = 0L

        while (isActive && running) {

            val t = withFrameNanos { it }

            if (prev != 0L && (!voiceMode || voice)) {
                val dt = ((t - prev) / 1_000_000_000f).coerceAtMost(0.05f)
                scroll.scrollBy(speed * 0.6f * density * dt)
            }

            prev = t
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(bg)
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {

        // Header

        Row(verticalAlignment = Alignment.CenterVertically) {

            Column(Modifier.weight(1f)) {
                Text(
                    "PROMPTPRO",
                    color = gold,
                    fontSize = 25.sp,
                    fontWeight = FontWeight.Black
                )

                Text(
                    "SMART VOICE TELEPROMPTER",
                    color = cream.copy(alpha = .6f),
                    fontSize = 10.sp
                )
            }

            Text(
                if (voice) "VOICE ON" else "STANDBY",
                color = gold,
                fontWeight = FontWeight.Bold
            )
        }

        // Camera Preview

        if (camera) {

            Box(
                Modifier
                    .fillMaxWidth()
                    .height(330.dp)
                    .background(Color.Black)
            ) {

                if (granted(ctx, Manifest.permission.CAMERA)) {

                    AndroidView(
                        factory = {
                            PreviewView(it).apply {
                                scaleType =
                                    PreviewView.ScaleType.FILL_CENTER
                                controller = cam
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )

                    Column(
                        Modifier
                            .align(Alignment.Center)
                            .fillMaxWidth()
                            .height(240.dp)
                            .background(Color.Black.copy(alpha = .38f))
                            .verticalScroll(scroll)
                            .padding(14.dp)
                    ) {
                        Text(
                            script,
                            color = Color.White,
                            fontSize = (font * .65f).sp,
                            lineHeight = (font * .95f).sp
                        )
                        Spacer(Modifier.height(180.dp))
                    }

                } else {

                    Text(
                        "Camera permission required",
                        color = cream,
                        modifier = Modifier.align(Alignment.Center)
                    )
                }
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {

                OutlinedButton(
                    onClick = {
                        front = !front
                        cam.cameraSelector =
                            if (front)
                                CameraSelector.DEFAULT_FRONT_CAMERA
                            else
                                CameraSelector.DEFAULT_BACK_CAMERA
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        if (front) "FRONT CAMERA" else "BACK CAMERA",
                        color = gold
                    )
                }

                Button(
                    onClick = {

                        if (
                            !granted(ctx, Manifest.permission.CAMERA) ||
                            !granted(ctx, Manifest.permission.RECORD_AUDIO)
                        ) {
                            requestPermissions()

                        } else if (!recording) {

                            val stamp = SimpleDateFormat(
                                "yyyyMMdd_HHmmss",
                                Locale.US
                            ).format(Date())

                            val values = ContentValues().apply {
                                put(
                                    MediaStore.Video.Media.DISPLAY_NAME,
                                    "PromptPro_$stamp.mp4"
                                )
                                put(
                                    MediaStore.Video.Media.MIME_TYPE,
                                    "video/mp4"
                                )
                                put(
                                    MediaStore.Video.Media.RELATIVE_PATH,
                                    "Movies/PromptPro"
                                )
                            }

                            val output = MediaStoreOutputOptions.Builder(
                                ctx.contentResolver,
                                MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                            )
                                .setContentValues(values)
                                .build()

                            try {

                                activeRecording = cam.startRecording(
                                    output,
                                    AudioConfig.create(true),
                                    ContextCompat.getMainExecutor(ctx)
                                ) { event: VideoRecordEvent ->

                                    when (event) {

                                        is VideoRecordEvent.Start -> {
                                            recording = true
                                            status = "Recording…"
                                        }

                                        is VideoRecordEvent.Finalize -> {
                                            recording = false
                                            activeRecording = null

                                            status =
                                                if (event.hasError())
                                                    "Recording failed"
                                                else
                                                    "Saved to Gallery / Movies / PromptPro"

                                            Toast.makeText(
                                                ctx,
                                                status,
                                                Toast.LENGTH_LONG
                                            ).show()
                                        }
                                    }
                                }

                            } catch (e: Exception) {
                                status =
                                    "Cannot start recording: ${e.localizedMessage}"
                            }

                        } else {
                            activeRecording?.stop()
                        }
                    },
                    modifier = Modifier.weight(1f),
                    colors = ButtonDefaults.buttonColors(
                        containerColor =
                            if (recording) Color.Red else gold,
                        contentColor = Color.Black
                    )
                ) {
                    Text(if (recording) "STOP REC" else "RECORD")
                }
            }

            OutlinedButton(
                onClick = {
                    activeRecording?.stop()
                    camera = false
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("CLOSE CAMERA", color = cream)
            }

        } else {

            Surface(
                color = panel,
                shape = MaterialTheme.shapes.large,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(280.dp)
            ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .verticalScroll(scroll)
                        .padding(18.dp)
                ) {
                    Text(
                        script,
                        color = cream,
                        fontSize = font.sp,
                        lineHeight = (font * 1.45f).sp
                    )
                    Spacer(Modifier.height(200.dp))
                }
            }
        }

        Text(status, color = gold, fontSize = 12.sp)

        // Start and Stop controls

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            Button(
                onClick = {
                    if (!granted(ctx, Manifest.permission.RECORD_AUDIO)) {
                        requestPermissions()
                    } else {
                        running = !running
                        status =
                            if (running) "Listening…" else "Stopped"
                    }
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(
                    containerColor = gold,
                    contentColor = bg
                )
            ) {
                Text(if (running) "PAUSE" else "START")
            }

            OutlinedButton(
                onClick = {
                    running = false
                    voice = false
                    status = "Stopped"
                }
            ) {
                Text("STOP", color = cream)
            }
        }

        // Settings

        Surface(
            color = panel,
            shape = MaterialTheme.shapes.large
        ) {

            Column(Modifier.padding(14.dp)) {

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Voice-follow mode",
                        modifier = Modifier.weight(1f),
                        color = cream
                    )
                    Switch(
                        voiceMode,
                        { voiceMode = it }
                    )
                }

                Text(
                    "Noisy-room sensitivity",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    sensitivity,
                    { sensitivity = it }
                )

                Text(
                    "Scroll speed",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    speed,
                    { speed = it },
                    valueRange = 10f..110f
                )

                Text(
                    "Text size",
                    color = cream,
                    fontSize = 12.sp
                )

                Slider(
                    font,
                    { font = it },
                    valueRange = 20f..48f
                )
            }
        }

        // Script controls

        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {

            OutlinedButton(
                onClick = {
                    editor = !editor
                    showLibrary = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("SCRIPT EDITOR", color = gold)
            }

            OutlinedButton(
                onClick = {
                    showLibrary = !showLibrary
                    editor = false
                },
                modifier = Modifier.weight(1f)
            ) {
                Text("MY SCRIPTS", color = gold)
            }
        }

        OutlinedButton(
            onClick = { importLauncher.launch(arrayOf("*/*")) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("IMPORT FILE (PDF / DOCX / TXT)", color = gold)
        }

        Button(
            onClick = {
                if (!granted(ctx, Manifest.permission.CAMERA)) {
                    requestPermissions()
                } else {
                    camera = true
                }
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = gold,
                contentColor = bg
            )
        ) {
            Text("OPEN CAMERA")
        }

        // Script editor

        if (editor) {

            Text(
                "EDITING: $selected",
                color = gold,
                fontWeight = FontWeight.Bold
            )

            BasicTextField(
                script,
                { script = it },
                Modifier
                    .fillMaxWidth()
                    .height(150.dp)
                    .background(panel)
                    .padding(12.dp),
                textStyle = TextStyle(
                    color = cream,
                    fontSize = 15.sp
                )
            )

            OutlinedButton(
                onClick = { saveCurrent() }
            ) {
                Text("SAVE SCRIPT", color = gold)
            }
        }

        // Script library

        if (showLibrary) {

            Row(verticalAlignment = Alignment.CenterVertically) {

                BasicTextField(
                    newName,
                    { newName = it },
                    Modifier
                        .weight(1f)
                        .background(panel)
                        .padding(10.dp),
                    textStyle = TextStyle(color = cream)
                )

                Button(
                    onClick = {
                        val n = newName.trim()

                        if (n.isNotEmpty() && !library.containsKey(n)) {

                            library = LinkedHashMap(library).apply {
                                put(n, "")
                            }

                            writeScripts(ctx, library)
                            selected = n
                            script = ""
                            newName = ""
                            editor = true
                            showLibrary = false
                        }
                    }
                ) {
                    Text("ADD")
                }
            }

            library.forEach { (name, body) ->

                Row(verticalAlignment = Alignment.CenterVertically) {

                    Column(Modifier.weight(1f)) {
                        Text(name, color = cream)
                        Text(
                            "${body.length} characters",
                            color = cream.copy(alpha = .5f),
                            fontSize = 10.sp
                        )
                    }

                    TextButton(
                        onClick = {
                            saveCurrent()
                            selected = name
                            script = library[name] ?: ""
                            editor = true
                            showLibrary = false
                        }
                    ) {
                        Text("OPEN", color = gold)
                    }

                    TextButton(
                        onClick = {

                            library = LinkedHashMap(library).apply {
                                remove(name)
                            }

                            writeScripts(ctx, library)

                            if (selected == name) {
                                selected =
                                    library.keys.firstOrNull() ?: "New"
                                script = library[selected] ?: ""
                            }
                        }
                    ) {
                        Text("DELETE", color = Color.Red)
                    }
                }
            }
        }

        Text(
            "1.5s silence pause · local script storage · Gallery export",
            color = cream.copy(alpha = .45f),
            fontSize = 10.sp
        )
    }
}
