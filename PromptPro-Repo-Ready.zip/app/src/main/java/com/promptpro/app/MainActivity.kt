package com.promptpro.app

import android.Manifest
import android.content.ContentValues
import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.content.Intent
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.view.KeyEvent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.camera.view.video.AudioConfig
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.animateScrollBy
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextLayoutResult
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

private val peach = Color(0xFFFFCC99)
private val barGray = Color(0xFF2C2C2C)
private val sheetColor = Color(0xFF282A36)
private val cardColor = Color(0xFF1C1C1E)

private val fontColors = listOf(
    Color.White,
    Color(0xFFE0E0E0),
    Color(0xFF9E9E9E),
    Color(0xFFFF5252),
    Color(0xFFF9E04B),
    Color(0xFF6FCF3F),
    Color(0xFF4A90FF)
)

private val bgColors = listOf(
    Color.Black,
    Color(0xFF3A50E0),
    Color(0xFF4A90FF),
    Color(0xFF6FCF3F),
    Color(0xFFF2DF40),
    Color(0xFFD13DC1),
    Color(0xFFFF5252)
)

class RemoteAction(
    val id: String,
    val label: String,
    val defaults: List<Int>
)

object RemoteMap {

    val actions = listOf(
        RemoteAction(
            "PAUSE", "Pause / Resume",
            listOf(
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_MEDIA_PLAY,
                KeyEvent.KEYCODE_MEDIA_PAUSE,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER,
                KeyEvent.KEYCODE_SPACE,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_HEADSETHOOK,
                KeyEvent.KEYCODE_BUTTON_A
            )
        ),
        RemoteAction(
            "UP", "Scroll Up",
            listOf(KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_DPAD_UP)
        ),
        RemoteAction(
            "DOWN", "Scroll Down",
            listOf(KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_DPAD_DOWN)
        ),
        RemoteAction(
            "SPEED_UP", "Increase Speed",
            listOf(KeyEvent.KEYCODE_VOLUME_UP)
        ),
        RemoteAction(
            "SPEED_DOWN", "Decrease Speed",
            listOf(KeyEvent.KEYCODE_VOLUME_DOWN)
        ),
        RemoteAction(
            "FONT_UP", "Increase Font Size",
            listOf(KeyEvent.KEYCODE_PLUS, KeyEvent.KEYCODE_EQUALS)
        ),
        RemoteAction(
            "FONT_DOWN", "Decrease Font Size",
            listOf(KeyEvent.KEYCODE_MINUS)
        ),
        RemoteAction(
            "NEXT_PARA", "Next Paragraph",
            listOf(KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_MEDIA_NEXT)
        ),
        RemoteAction(
            "PREV_PARA", "Previous Paragraph",
            listOf(KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        ),
        RemoteAction(
            "RESET", "Restart from Top",
            listOf(KeyEvent.KEYCODE_MEDIA_STOP)
        )
    )

    // keyCode -> action id (custom buttons override the defaults)

    fun build(p: SharedPreferences): HashMap<Int, String> {

        val m = HashMap<Int, String>()

        for (a in actions) {
            if (p.getInt("rk_" + a.id, -1) == -1) {
                for (c in a.defaults) {
                    if (!m.containsKey(c)) {
                        m[c] = a.id
                    }
                }
            }
        }

        for (a in actions) {
            val c = p.getInt("rk_" + a.id, -1)
            if (c != -1) {
                m[c] = a.id
            }
        }

        return m
    }

    fun keyName(code: Int): String =
        KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

// Lines starting with # mark a new paragraph (the # itself is hidden).
// Without any #, paragraphs are separated by an empty line.
// Returns the text to show and the start offsets of the paragraphs.

fun parseScript(raw: String): Pair<String, List<Int>> {

    val lines = raw.split("\n")

    var hasHash = false
    for (ln in lines) {
        if (ln.trimStart().startsWith("#")) {
            hasHash = true
            break
        }
    }

    val sb = StringBuilder()
    val marks = ArrayList<Int>()

    for ((i, ln) in lines.withIndex()) {

        var line = ln

        if (hasHash) {
            val t = ln.trimStart()
            if (t.startsWith("#")) {
                marks.add(sb.length)
                line = t.trimStart('#').trimStart()
            }
        } else if (i > 0 && lines[i - 1].isBlank() && ln.isNotBlank()) {
            marks.add(sb.length)
        }

        sb.append(line)

        if (i < lines.size - 1) {
            sb.append('\n')
        }
    }

    return Pair(sb.toString(), marks)
}

object Remote {

    var prefs: SharedPreferences? = null
    var onAction: ((String) -> Unit)? = null
    var learn: ((Int) -> Unit)? = null

    fun wants(code: Int): Boolean {
        if (learn != null) {
            return code != KeyEvent.KEYCODE_BACK
        }
        val p = prefs ?: return false
        return onAction != null && RemoteMap.build(p).containsKey(code)
    }

    fun deliver(code: Int) {
        val l = learn
        if (l != null) {
            l(code)
            return
        }
        val p = prefs ?: return
        val id = RemoteMap.build(p)[code] ?: return
        onAction?.invoke(id)
    }
}

class MainActivity : ComponentActivity() {

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (Remote.wants(event.keyCode)) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                Remote.deliver(event.keyCode)
            }
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private val perms =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Remote.prefs = getSharedPreferences("pp", Context.MODE_PRIVATE)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = peach,
                    background = Color.Black,
                    surface = cardColor,
                    onSurface = Color.White,
                    onBackground = Color.White
                )
            ) {
                PromptPro {
                    perms.launch(
                        arrayOf(
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO,
                            Manifest.permission.POST_NOTIFICATIONS
                        )
                    )
                }
            }
        }
    }
}

private fun displayName(c: Context, uri: Uri): String {
    var name = "Imported script.txt"
    c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) {
            name = cur.getString(i) ?: name
        }
    }
    return name
}

private fun extractText(c: Context, uri: Uri, ext: String): String {
    return when (ext) {
        "docx" -> docxText(c, uri)
        "pdf" -> pdfText(c, uri)
        else -> c.contentResolver.openInputStream(uri)!!
            .bufferedReader().use { it.readText() }
    }
}

private fun docxText(c: Context, uri: Uri): String {
    c.contentResolver.openInputStream(uri)!!.use { ins ->
        java.util.zip.ZipInputStream(ins).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    return xmlToText(xml)
                }
                e = zip.nextEntry
            }
        }
    }
    return ""
}

private fun xmlToText(xml: String): String {
    return xml
        .replace("</w:p>", "\n")
        .replace(Regex("<w:br[^>]*/>"), "\n")
        .replace(Regex("<w:tab[^>]*/>"), "\t")
        .replace(Regex("<[^>]+>"), "")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
}

private fun pdfText(c: Context, uri: Uri): String {
    com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(c.applicationContext)
    return c.contentResolver.openInputStream(uri)!!.use { ins ->
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(ins).use { doc ->
            com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc)
        }
    }.trim()
}

private fun granted(c: Context, p: String): Boolean {
    return ContextCompat.checkSelfPermission(
        c, p
    ) == PackageManager.PERMISSION_GRANTED
}

private fun readScripts(c: Context): LinkedHashMap<String, String> {

    val raw = c.getSharedPreferences("pp", 0)
        .getString("scripts", null)
        ?: return linkedMapOf(
            "My first script" to
                "Namaskar dosto! Apni script yahan likhein."
        )

    return try {
        val j = JSONObject(raw)
        LinkedHashMap<String, String>().apply {
            j.keys().forEach { k ->
                put(k, j.optString(k))
            }
        }
    } catch (_: Exception) {
        linkedMapOf("My first script" to "")
    }
}

private fun writeScripts(
    c: Context,
    m: Map<String, String>
) {
    val j = JSONObject()
    m.forEach { (k, v) -> j.put(k, v) }

    c.getSharedPreferences("pp", 0)
        .edit()
        .putString("scripts", j.toString())
        .apply()
}


@Composable
fun PromptPro(requestPermissions: () -> Unit) {

    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("pp", 0) }
    SideEffect { Remote.prefs = prefs }

    // Scripts

    var library by remember { mutableStateOf(readScripts(ctx)) }
    var selected by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("") }

    // 0 = scripts list, 1 = teleprompter, 2 = editor
    var screen by remember { mutableIntStateOf(0) }

    // Settings (saved on the phone)

    var font by remember { mutableFloatStateOf(prefs.getFloat("font", 36f)) }
    var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 326f)) }
    var autoPause by remember { mutableStateOf(prefs.getBoolean("autoPause", false)) }
    var fontColorIdx by remember { mutableIntStateOf(prefs.getInt("fontColor", 0)) }
    var mirror by remember { mutableStateOf(prefs.getBoolean("mirror", false)) }
    var margin by remember { mutableFloatStateOf(prefs.getFloat("margin", 24f)) }
    var playDelay by remember { mutableFloatStateOf(prefs.getFloat("delay", 0f)) }
    var cycle by remember { mutableStateOf(prefs.getBoolean("cycle", false)) }
    var bgIdx by remember { mutableIntStateOf(prefs.getInt("bg", 0)) }
    var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sens", 0.55f)) }
    var pauseAfter by remember { mutableFloatStateOf(prefs.getFloat("pauseAfter", 0.3f)) }
    var smartVoice by remember { mutableStateOf(prefs.getBoolean("smart", true)) }
    var tapPause by remember { mutableStateOf(prefs.getBoolean("tapPause", true)) }
    var remoteOn by remember { mutableStateOf(prefs.getBoolean("remote", true)) }
    var remoteStep by remember { mutableFloatStateOf(prefs.getFloat("remoteStep", 60f)) }
    var learning by remember { mutableStateOf<RemoteAction?>(null) }
    var mapVersion by remember { mutableIntStateOf(0) }
    var prevScreen by remember { mutableIntStateOf(0) }

    LaunchedEffect(
        font, speed, autoPause, fontColorIdx, mirror,
        margin, playDelay, cycle, bgIdx, sensitivity, pauseAfter,
        smartVoice, tapPause, remoteOn, remoteStep
    ) {
        prefs.edit()
            .putFloat("font", font)
            .putFloat("speed", speed)
            .putBoolean("autoPause", autoPause)
            .putInt("fontColor", fontColorIdx)
            .putBoolean("mirror", mirror)
            .putFloat("margin", margin)
            .putFloat("delay", playDelay)
            .putBoolean("cycle", cycle)
            .putInt("bg", bgIdx)
            .putFloat("sens", sensitivity)
            .putFloat("pauseAfter", pauseAfter)
            .putBoolean("smart", smartVoice)
            .putBoolean("tapPause", tapPause)
            .putBoolean("remote", remoteOn)
            .putFloat("remoteStep", remoteStep)
            .apply()
    }

    // Teleprompter state

    var running by remember { mutableStateOf(false) }
    var voice by remember { mutableStateOf(false) }
    var micInfo by remember { mutableStateOf("") }
    var countdown by remember { mutableIntStateOf(0) }
    var textHeightPx by remember { mutableIntStateOf(0) }
    val layoutHolder = remember { arrayOfNulls<TextLayoutResult>(1) }
    val parsed = remember(script) { parseScript(script) }
    var showSettings by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    // Camera state

    var cameraOn by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var recording by remember { mutableStateOf(false) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }

    val scroll = rememberScrollState()

    val cam = remember(ctx) {
        LifecycleCameraController(ctx).apply {
            setEnabledUseCases(CameraController.VIDEO_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
        }
    }

    DisposableEffect(cam, owner, cameraOn, screen) {
        if (
            cameraOn && screen == 1 &&
            granted(ctx, Manifest.permission.CAMERA)
        ) {
            try {
                cam.bindToLifecycle(owner)
            } catch (_: Throwable) {
            }
        }
        onDispose {
            activeRecording?.stop()
            try {
                cam.unbind()
            } catch (_: Throwable) {
            }
        }
    }

    DisposableEffect(screen) {
        view.keepScreenOn = screen == 1
        onDispose { view.keepScreenOn = false }
    }

    // Helper functions

    fun saveCurrent() {
        if (selected.isNotEmpty()) {
            library = LinkedHashMap(library).apply {
                put(selected, script)
            }
            writeScripts(ctx, library)
        }
    }

    fun openScript(name: String) {
        selected = name
        script = library[name] ?: ""
        running = false
        voice = false
        countdown = 0
        showSettings = false
        scope.launch { scroll.scrollTo(0) }
        screen = 1
    }

    fun leaveReader() {
        running = false
        voice = false
        countdown = 0
        activeRecording?.stop()
        cameraOn = false
        showSettings = false
        screen = 0
    }

    fun onPlay() {
        if (running) {
            running = false
            return
        }
        if (countdown > 0) return

        if (
            autoPause &&
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            requestPermissions()
            return
        }

        val d = playDelay.toInt()

        scope.launch {
            if (scroll.maxValue > 0 && scroll.value >= scroll.maxValue - 1) {
                scroll.scrollTo(0)
            }
            if (d > 0) {
                var i = d
                while (i > 0) {
                    countdown = i
                    delay(1000)
                    i--
                }
                countdown = 0
            }
            running = true
        }
    }

    fun toggleRecording() {

        if (
            !granted(ctx, Manifest.permission.CAMERA) ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            requestPermissions()
            return
        }

        if (recording) {
            activeRecording?.stop()
            return
        }

        val stamp = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.US
        ).format(Date())

        val values = ContentValues().apply {
            put(
                MediaStore.Video.Media.DISPLAY_NAME,
                "PromptPro_$stamp.mp4"
            )
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                "Movies/PromptPro"
            )
        }

        val output = MediaStoreOutputOptions.Builder(
            ctx.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )
            .setContentValues(values)
            .build()

        try {

            activeRecording = cam.startRecording(
                output,
                AudioConfig.create(true),
                ContextCompat.getMainExecutor(ctx)
            ) { event: VideoRecordEvent ->

                when (event) {

                    is VideoRecordEvent.Start -> {
                        recording = true
                    }

                    is VideoRecordEvent.Finalize -> {
                        recording = false
                        activeRecording = null

                        val msg =
                            if (event.hasError())
                                "Recording failed"
                            else
                                "Saved to Gallery / Movies / PromptPro"

                        Toast.makeText(
                            ctx, msg, Toast.LENGTH_LONG
                        ).show()
                    }

                    else -> {}
                }
            }

        } catch (e: Exception) {
            Toast.makeText(
                ctx,
                "Cannot start recording: ${e.localizedMessage}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // File import (PDF / DOCX / TXT)

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) {
                    displayName(ctx, uri)
                }
                val ext = name.substringAfterLast('.', "")
                    .lowercase(Locale.ROOT)

                if (ext != "pdf" && ext != "docx" && ext != "txt") {
                    Toast.makeText(
                        ctx, "Sirf PDF, DOCX ya TXT file chuno",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        ctx, "Importing...", Toast.LENGTH_SHORT
                    ).show()

                    val text = withContext(Dispatchers.IO) {
                        try {
                            extractText(ctx, uri, ext)
                        } catch (e: Throwable) {
                            null
                        }
                    }

                    if (text == null) {
                        Toast.makeText(
                            ctx, "File padh nahi paya",
                            Toast.LENGTH_LONG
                        ).show()
                    } else if (text.isBlank()) {
                        Toast.makeText(
                            ctx,
                            "File me text nahi mila (scanned PDF ho sakti hai)",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        saveCurrent()
                        val base = name.substringBeforeLast('.')
                            .ifBlank { "Imported" }
                        var key = base
                        var n = 2
                        while (library.containsKey(key)) {
                            key = "$base ($n)"
                            n++
                        }
                        library = LinkedHashMap(library).apply {
                            put(key, text)
                        }
                        writeScripts(ctx, library)
                        openScript(key)
                        Toast.makeText(
                            ctx, "Imported: $key", Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    var hud by remember { mutableStateOf("") }

    LaunchedEffect(hud) {
        if (hud.isNotEmpty()) {
            delay(1200)
            hud = ""
        }
    }

    fun jump(dir: Int) {
        val px = remoteStep * 3f * ctx.resources.displayMetrics.density
        scope.launch { scroll.animateScrollBy(px * dir) }
    }

    fun changeSpeed(delta: Float) {
        speed = (speed + delta).coerceIn(60f, 900f)
        hud = "Speed ${speed.toInt()}"
    }

    fun changeFont(delta: Float) {
        font = (font + delta).coerceIn(20f, 64f)
        hud = "Font ${font.toInt()}"
    }

    fun paragraph(dir: Int) {
        val lay = layoutHolder[0] ?: return
        val len = parsed.first.length
        if (len == 0) return
        val tops = parsed.second.map {
            lay.getLineTop(lay.getLineForOffset(it.coerceIn(0, len - 1)))
        }
        val y = scroll.value
        val target =
            if (dir > 0) tops.firstOrNull { it > y + 8 }
            else tops.lastOrNull { it < y - 8 }
        val to = target?.toInt() ?: (if (dir > 0) y else 0)
        scope.launch { scroll.animateScrollTo(to) }
    }

    fun handleAction(id: String) {
        when (id) {
            "PAUSE" -> onPlay()
            "UP" -> jump(-1)
            "DOWN" -> jump(1)
            "SPEED_UP" -> changeSpeed(20f)
            "SPEED_DOWN" -> changeSpeed(-20f)
            "FONT_UP" -> changeFont(2f)
            "FONT_DOWN" -> changeFont(-2f)
            "NEXT_PARA" -> paragraph(1)
            "PREV_PARA" -> paragraph(-1)
            "RESET" -> {
                running = false
                voice = false
                countdown = 0
                scope.launch { scroll.scrollTo(0) }
            }
            else -> {}
        }
    }

    fun startFloating() {

        if (!android.provider.Settings.canDrawOverlays(ctx)) {
            Toast.makeText(
                ctx,
                "'Display over other apps' allow karo, phir dobara dabao",
                Toast.LENGTH_LONG
            ).show()
            try {
                ctx.startActivity(
                    Intent(
                        android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + ctx.packageName)
                    )
                )
            } catch (_: Throwable) {
            }
            return
        }

        saveCurrent()
        running = false
        voice = false

        try {
            val i = Intent(ctx, FloatingService::class.java)
                .putExtra("text", script)
            ContextCompat.startForegroundService(ctx, i)
            (ctx as? Activity)?.moveTaskToBack(true)
        } catch (e: Throwable) {
            Toast.makeText(
                ctx,
                "Floating window start nahi hui: ${e.localizedMessage}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // Bluetooth remote / keyboard keys

    DisposableEffect(screen, remoteOn) {

        var session: MediaSession? = null

        if (screen == 1 && remoteOn) {
            Remote.onAction = { id -> handleAction(id) }
        }

        if ((screen == 1 || screen == 3) && remoteOn) {

            try {
                val ms = MediaSession(ctx, "PromptPro")

                ms.setCallback(object : MediaSession.Callback() {
                    override fun onMediaButtonEvent(
                        mediaButtonIntent: Intent
                    ): Boolean {
                        @Suppress("DEPRECATION")
                        val ke = mediaButtonIntent
                            .getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT)
                        if (
                            ke != null &&
                            ke.action == KeyEvent.ACTION_DOWN &&
                            ke.repeatCount == 0
                        ) {
                            Remote.deliver(ke.keyCode)
                        }
                        return true
                    }
                })

                ms.setPlaybackState(
                    PlaybackState.Builder()
                        .setActions(
                            PlaybackState.ACTION_PLAY or
                                PlaybackState.ACTION_PAUSE or
                                PlaybackState.ACTION_PLAY_PAUSE or
                                PlaybackState.ACTION_SKIP_TO_NEXT or
                                PlaybackState.ACTION_SKIP_TO_PREVIOUS or
                                PlaybackState.ACTION_STOP
                        )
                        .setState(PlaybackState.STATE_PLAYING, 0L, 1f)
                        .build()
                )

                ms.isActive = true
                session = ms

            } catch (_: Throwable) {
            }
        }

        onDispose {
            Remote.onAction = null
            try {
                session?.isActive = false
                session?.release()
            } catch (_: Throwable) {
            }
        }
    }

    // Learn a remote button for an action

    DisposableEffect(learning) {

        val act = learning

        if (act != null) {
            Remote.learn = { code ->
                val ed = prefs.edit()
                for (a in RemoteMap.actions) {
                    if (a.id != act.id && prefs.getInt("rk_" + a.id, -1) == code) {
                        ed.remove("rk_" + a.id)
                    }
                }
                ed.putInt("rk_" + act.id, code)
                ed.apply()
                mapVersion++
                learning = null
                Toast.makeText(
                    ctx,
                    act.label + ": " + RemoteMap.keyName(code),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        onDispose { Remote.learn = null }
    }

    BackHandler(enabled = screen != 0 || showSettings || learning != null) {
        if (learning != null) {
            learning = null
        } else if (showSettings) {
            showSettings = false
        } else if (screen == 3) {
            screen = prevScreen
        } else if (screen == 2) {
            saveCurrent()
            screen = 1
        } else {
            leaveReader()
        }
    }

    // Voice detection (Auto Pause): scrolls only while you are talking

    LaunchedEffect(running, autoPause, sensitivity, pauseAfter, screen) {

        if (
            !running ||
            !autoPause ||
            screen != 1 ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            voice = false
            micInfo = ""
            return@LaunchedEffect
        }

        withContext(Dispatchers.IO) {

            var rec: AudioRecord? = null

            try {

                val rate = 16000

                val size = AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    size * 2
                )
                rec = r

                if (r.state != AudioRecord.STATE_INITIALIZED) {
                    micInfo = "Mic nahi mila - Auto Pause band"
                    voice = true
                    return@withContext
                }

                val buf = ShortArray(512)
                var floor = 0.0
                var first = true
                var last = 0L
                var lastShown = 0L
                var above = 0
                var hp = 0.0
                var lp = 0.0
                var prevX = 0.0
                var speechLevel = -30.0
                var avgGap = 250.0
                var quiet = false
                var quietStart = 0L

                r.startRecording()

                if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    micInfo = "Mic start nahi hua - Auto Pause band"
                    voice = true
                    return@withContext
                }

                while (isActive && running) {

                    val n = r.read(buf, 0, buf.size)

                    if (n <= 0) {
                        micInfo = "Mic read error ($n)"
                        delay(50)
                        continue
                    }

                    // Speech band filter (about 300 Hz - 3400 Hz):
                    // fan / AC ki low rumble ko kam karta hai

                    var sum = 0.0

                    for (i in 0 until n) {
                        val x = buf[i].toDouble() / 32768.0
                        hp = 0.8946 * (hp + x - prevX)
                        prevX = x
                        lp += 0.572 * (hp - lp)
                        sum += lp * lp
                    }

                    val db = 20 * log10(
                        sqrt(sum / n).coerceAtLeast(.000001)
                    )

                    val now = System.currentTimeMillis()

                    // Background noise level: girta tez, badhta dheere

                    if (first) {
                        floor = db
                        first = false
                    } else if (db < floor) {
                        floor += (db - floor) * 0.25
                    } else {
                        floor += (db - floor) * (if (voice) 0.0015 else 0.01)
                    }

                    val smart = smartVoice

                    val margin =
                        if (smart)
                            ((speechLevel - floor) * 0.45).coerceIn(5.0, 16.0)
                        else
                            6.0 + (1 - sensitivity.toDouble()) * 14.0

                    val pauseMs =
                        if (smart)
                            (avgGap * 2.0).coerceIn(250.0, 700.0).toLong()
                        else
                            (pauseAfter * 1000f).toLong()

                    val threshold =
                        max(-58.0, floor + margin) - (if (voice) 2.0 else 0.0)

                    if (db > threshold) {
                        if (quiet) {
                            val gap = (now - quietStart).toDouble()
                            if (gap in 60.0..1500.0) {
                                avgGap = avgGap * 0.85 + gap * 0.15
                            }
                            quiet = false
                        }
                        above++
                        last = now
                        if (above >= 2) {
                            voice = true
                        }
                        if (voice) {
                            speechLevel = speechLevel * 0.98 + db * 0.02
                        }
                    } else {
                        if (!quiet) {
                            quiet = true
                            quietStart = now
                        }
                        above = 0
                        if (!voice) {
                            // halki awaaz ke liye dheere dheere sensitivity badhao
                            speechLevel += ((floor + 14.0) - speechLevel) * 0.001
                        }
                        if (voice && now - last >= pauseMs) {
                            voice = false
                        }
                    }

                    if (now - lastShown > 300) {
                        lastShown = now
                        micInfo =
                            "Mic ${db.toInt()} | noise ${floor.toInt()} | need ${threshold.toInt()} dB"
                    }
                }

            } catch (e: Throwable) {
                if (e is java.util.concurrent.CancellationException) throw e
                micInfo = "Mic error: ${e.localizedMessage}"
                voice = true
            } finally {
                try {
                    rec?.stop()
                } catch (_: Throwable) {
                }
                try {
                    rec?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    // Automatic scrolling (speed is in characters per minute)

    LaunchedEffect(running, voice, autoPause, speed, textHeightPx, cycle) {

        val pxPerChar = textHeightPx.toFloat() / max(1, parsed.first.length)
        var prev = 0L

        while (isActive && running) {

            val t = withFrameNanos { it }

            if (prev != 0L && (!autoPause || voice)) {

                val dt = ((t - prev) / 1_000_000_000f).coerceAtMost(0.05f)

                scroll.scrollBy(speed / 60f * pxPerChar * dt)

                if (
                    scroll.maxValue > 0 &&
                    scroll.value >= scroll.maxValue - 1
                ) {
                    if (cycle) {
                        scroll.scrollTo(0)
                    } else {
                        running = false
                    }
                }
            }

            prev = t
        }
    }

    // Screens

    val bgColor = bgColors[bgIdx.coerceIn(0, bgColors.size - 1)]
    val textColor = fontColors[fontColorIdx.coerceIn(0, fontColors.size - 1)]

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {

        if (screen == 0) {

            // ---------- Scripts list ----------

            Column(Modifier.fillMaxSize()) {

                TopBar(title = "PromptPro  v2.3", onBack = null) {}

                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    if (library.isEmpty()) {
                        Text(
                            "Abhi koi script nahi hai. Neeche + NEW SCRIPT dabao ya file import karo.",
                            color = Color.Gray
                        )
                    }

                    library.forEach { (name, body) ->

                        Surface(
                            color = cardColor,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { openScript(name) }
                        ) {
                            Row(
                                Modifier.padding(
                                    start = 16.dp,
                                    top = 8.dp,
                                    bottom = 8.dp,
                                    end = 4.dp
                                ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Column(Modifier.weight(1f)) {
                                    Text(
                                        name,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        "${body.length} characters",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        library = LinkedHashMap(library).apply {
                                            remove(name)
                                        }
                                        writeScripts(ctx, library)
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFFF6B6B)
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    Button(
                        onClick = {
                            newName = ""
                            showNew = true
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = peach,
                            contentColor = Color.Black
                        )
                    ) {
                        Text("+ NEW SCRIPT")
                    }

                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("IMPORT FILE", color = peach)
                    }
                }

                OutlinedButton(
                    onClick = {
                        prevScreen = 0
                        screen = 3
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 16.dp, end = 16.dp, bottom = 16.dp)
                ) {
                    Text("REMOTE SETTINGS", color = peach)
                }
            }

        } else if (screen == 3) {

            // ---------- Remote settings ----------

            Column(Modifier.fillMaxSize()) {

                TopBar(
                    title = "Remote Settings",
                    onBack = { screen = prevScreen }
                ) {}

                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp)
                ) {

                    SettingSwitch(
                        "Bluetooth Remote",
                        "Remote / keyboard ke buttons se control",
                        remoteOn
                    ) { remoteOn = it }

                    val version = mapVersion

                    RemoteMap.actions.forEach { a ->

                        val code = prefs.getInt("rk_" + a.id, -1)

                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { learning = a }
                                .padding(vertical = 18.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                a.label,
                                color = Color.White,
                                fontSize = 17.sp,
                                modifier = Modifier.weight(1f)
                            )
                            Text(
                                if (code == -1) "Default"
                                else RemoteMap.keyName(code),
                                color = if (code == -1) Color.Gray else peach,
                                fontSize = 15.sp
                            )
                        }

                        Box(
                            Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(Color(0x22FFFFFF))
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    SettingSlider(
                        "Scroll Sensitivity", remoteStep,
                        { remoteStep = it }, 10f..100f,
                        hint = "${remoteStep.toInt()}"
                    )

                    Text(
                        "Kisi kaam par tap karke remote ka button dabao, wahi button us kaam ke liye lag jayega. Script me # lagao to nayi paragraph ban jayegi; Next/Previous Paragraph un # marks par jayenge (# na ho to khali line se).",
                        color = Color.Gray,
                        fontSize = 13.sp,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Spacer(Modifier.height(24.dp))
                }
            }

        } else if (screen == 2) {

            // ---------- Script editor ----------

            Column(
                Modifier
                    .fillMaxSize()
                    .imePadding()
            ) {

                TopBar(
                    title = selected,
                    onBack = {
                        saveCurrent()
                        screen = 1
                    }
                ) {
                    IconButton(
                        onClick = {
                            saveCurrent()
                            Toast.makeText(
                                ctx, "Script saved", Toast.LENGTH_SHORT
                            ).show()
                        }
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Save",
                            tint = peach
                        )
                    }
                }

                BasicTextField(
                    value = script,
                    onValueChange = { script = it },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp),
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 20.sp,
                        lineHeight = 30.sp
                    ),
                    cursorBrush = SolidColor(peach)
                )
            }

        } else {

            // ---------- Teleprompter (Classic Mode) ----------

            Column(Modifier.fillMaxSize()) {

                TopBar(
                    title = "Classic Mode",
                    onBack = { leaveReader() }
                ) {
                    IconButton(onClick = { startFloating() }) {
                        Text("⧉", color = peach, fontSize = 24.sp)
                    }
                    IconButton(
                        onClick = {
                            running = false
                            saveCurrent()
                            screen = 2
                        }
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = Color.White
                        )
                    }
                }

                BoxWithConstraints(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(bgColor)
                        .pointerInput(tapPause) {
                            if (tapPause) {
                                detectTapGestures(onTap = { onPlay() })
                            }
                        }
                ) {

                    val h = maxHeight

                    if (cameraOn && granted(ctx, Manifest.permission.CAMERA)) {
                        AndroidView(
                            factory = {
                                PreviewView(it).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                    controller = cam
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = if (mirror) -1f else 1f
                            }
                            .verticalScroll(scroll)
                    ) {

                        Spacer(Modifier.height(h * 0.48f))

                        Text(
                            parsed.first,
                            color = textColor,
                            fontSize = font.sp,
                            lineHeight = (font * 1.45f).sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = margin.dp),
                            onTextLayout = {
                                textHeightPx = it.size.height
                                layoutHolder[0] = it
                            }
                        )

                        Spacer(Modifier.height(h * 0.52f))
                    }

                    // Reading line

                    Box(
                        Modifier
                            .offset(y = h * 0.48f)
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(peach)
                    )

                    Box(
                        Modifier
                            .offset(y = h * 0.48f - 21.dp)
                            .width(26.dp)
                            .height(42.dp)
                            .background(
                                peach,
                                RoundedCornerShape(
                                    topEnd = 8.dp,
                                    bottomEnd = 8.dp
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▶", color = Color.Black, fontSize = 12.sp)
                    }

                    Row(
                        Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 10.dp)
                            .background(
                                Color(0x66000000),
                                RoundedCornerShape(24.dp)
                            ),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "−",
                            color = Color.White,
                            fontSize = 24.sp,
                            modifier = Modifier
                                .clickable { changeSpeed(-20f) }
                                .padding(horizontal = 18.dp, vertical = 6.dp)
                        )
                        Text(
                            "${speed.toInt()}",
                            color = peach,
                            fontSize = 14.sp
                        )
                        Text(
                            "+",
                            color = Color.White,
                            fontSize = 24.sp,
                            modifier = Modifier
                                .clickable { changeSpeed(20f) }
                                .padding(horizontal = 18.dp, vertical = 6.dp)
                        )
                    }

                    if (hud.isNotEmpty()) {
                        Text(
                            hud,
                            color = peach,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 64.dp)
                        )
                    }

                    if (countdown > 0) {
                        Text(
                            countdown.toString(),
                            color = peach,
                            fontSize = 96.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    if (autoPause && running && micInfo.isNotEmpty()) {
                        Text(
                            micInfo,
                            color = peach,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        )
                    }

                    if (cameraOn) {
                        Row(
                            Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {

                            Button(
                                onClick = {
                                    front = !front
                                    cam.cameraSelector =
                                        if (front)
                                            CameraSelector.DEFAULT_FRONT_CAMERA
                                        else
                                            CameraSelector.DEFAULT_BACK_CAMERA
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0x99000000),
                                    contentColor = Color.White
                                )
                            ) {
                                Text(if (front) "FRONT" else "BACK")
                            }

                            Button(
                                onClick = { toggleRecording() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor =
                                        if (recording) Color.Red else peach,
                                    contentColor = Color.Black
                                )
                            ) {
                                Text(if (recording) "STOP REC" else "REC")
                            }
                        }
                    }
                }

                // Bottom controls

                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .padding(horizontal = 12.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    IconButton(
                        onClick = {
                            if (!cameraOn) {
                                if (!granted(ctx, Manifest.permission.CAMERA)) {
                                    requestPermissions()
                                } else {
                                    cameraOn = true
                                }
                            } else {
                                activeRecording?.stop()
                                cameraOn = false
                            }
                        }
                    ) {
                        Text(
                            "🎥",
                            fontSize = 26.sp,
                            color = if (cameraOn) peach else Color.White
                        )
                    }

                    Box(
                        Modifier
                            .size(84.dp)
                            .clip(CircleShape)
                            .background(peach)
                            .clickable { onPlay() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (running || countdown > 0) {
                            PauseIcon()
                        } else {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            running = false
                            voice = false
                            countdown = 0
                            scope.launch { scroll.scrollTo(0) }
                        }
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            tab = 0
                            showSettings = true
                        }
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                }
            }

            // ---------- Settings sheet ----------

            if (showSettings) {

                val secs = (script.length / max(speed, 1f) * 60f).toInt()

                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            sheetColor,
                            RoundedCornerShape(
                                topStart = 24.dp,
                                topEnd = 24.dp
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Estimated recording time: ${secs / 60} min ${secs % 60} sec",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { showSettings = false }) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.Gray
                            )
                        }
                    }

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TabLabel("General", tab == 0) { tab = 0 }
                        TabLabel("More", tab == 1) { tab = 1 }
                    }

                    Column(
                        Modifier
                            .heightIn(max = 400.dp)
                            .verticalScroll(rememberScrollState())
                    ) {

                        if (tab == 0) {

                            SettingSlider(
                                "Font Size", font, { font = it }, 20f..64f
                            )

                            SettingSlider(
                                "Scroll Speed", speed, { speed = it }, 60f..900f,
                                hint = "${speed.toInt()} characters/min"
                            )

                            SettingSwitch(
                                "Voice Control",
                                "Bolne par script chalegi, chup hone par rukegi",
                                autoPause
                            ) {
                                autoPause = it
                                if (it && !granted(ctx, Manifest.permission.RECORD_AUDIO)) {
                                    requestPermissions()
                                }
                            }

                            SettingSwitch(
                                "Smart Sensitivity",
                                "Noise, halki awaaz aur bolne ki speed ke hisaab se khud adjust",
                                smartVoice
                            ) { smartVoice = it }

                            if (!smartVoice) {

                                SettingSlider(
                                    "Mic Sensitivity", sensitivity,
                                    { sensitivity = it }, 0f..1f,
                                    hint = "Noisy room me left (kam) karo"
                                )

                                SettingSlider(
                                    "Pause After", pauseAfter,
                                    { pauseAfter = it }, 0.1f..1.5f,
                                    hint = "${"%.1f".format(pauseAfter)} sec chup rehne par"
                                )
                            }

                            SettingSwitch(
                                "Tap to Pause / Play",
                                "Screen par tap karke ruko ya chalao",
                                tapPause
                            ) { tapPause = it }

                            Text(
                                "Font Color",
                                color = Color.White,
                                fontSize = 17.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
                            )
                            SwatchRow(fontColors, fontColorIdx) { fontColorIdx = it }

                            SettingSwitch(
                                "Mirror Mode",
                                "Use with teleprompter rig",
                                mirror
                            ) { mirror = it }

                        } else {

                            SettingSlider(
                                "Margins", margin, { margin = it }, 0f..60f
                            )

                            SettingSlider(
                                "Play Delay", playDelay, { playDelay = it },
                                0f..5f, steps = 4,
                                hint = "${playDelay.toInt()} sec"
                            )

                            SettingSwitch(
                                "Cycle Scrolling", null, cycle
                            ) { cycle = it }

                            SettingSwitch(
                                "Bluetooth Remote",
                                "Play/Pause = start/stop, Page/Arrow = aage-peeche, Volume = speed",
                                remoteOn
                            ) { remoteOn = it }

                            Text(
                                "Remote Buttons Setup  ›",
                                color = peach,
                                fontSize = 17.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        showSettings = false
                                        running = false
                                        prevScreen = 1
                                        screen = 3
                                    }
                                    .padding(vertical = 12.dp)
                            )

                            Text(
                                "Background",
                                color = Color.White,
                                fontSize = 17.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
                            )
                            SwatchRow(bgColors, bgIdx) { bgIdx = it }
                        }

                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    // Waiting for a remote button press

    val learnAct = learning

    if (learnAct != null) {
        Box(
            Modifier
                .fillMaxSize()
                .background(Color(0xCC000000))
                .pointerInput(Unit) { detectTapGestures(onTap = { }) },
            contentAlignment = Alignment.Center
        ) {
            Column(
                Modifier
                    .padding(32.dp)
                    .background(sheetColor, RoundedCornerShape(20.dp))
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    learnAct.label,
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.height(12.dp))
                Text(
                    "Ab remote ka wo button dabao jo is kaam ke liye lagana hai.",
                    color = Color.Gray,
                    fontSize = 15.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(16.dp))
                Row {
                    TextButton(
                        onClick = {
                            prefs.edit().remove("rk_" + learnAct.id).apply()
                            mapVersion++
                            learning = null
                        }
                    ) {
                        Text("DEFAULT", color = peach)
                    }
                    TextButton(onClick = { learning = null }) {
                        Text("CANCEL")
                    }
                }
            }
        }
    }

    // New script dialog

    if (showNew) {
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("New script") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    label = { Text("Script name") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val n = newName.trim()
                        if (n.isEmpty()) {
                            // nothing
                        } else if (library.containsKey(n)) {
                            Toast.makeText(
                                ctx,
                                "Is naam ki script pehle se hai",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            saveCurrent()
                            library = LinkedHashMap(library).apply {
                                put(n, "")
                            }
                            writeScripts(ctx, library)
                            selected = n
                            script = ""
                            running = false
                            showNew = false
                            screen = 2
                        }
                    }
                ) {
                    Text("ADD", color = peach)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNew = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}


@Composable
private fun TopBar(
    title: String,
    onBack: (() -> Unit)?,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(barGray)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
        } else {
            Spacer(Modifier.width(12.dp))
        }

        Text(
            title,
            color = Color.White,
            fontSize = 20.sp,
            maxLines = 1,
            textAlign =
                if (onBack != null) TextAlign.Center else TextAlign.Start,
            modifier = Modifier.weight(1f)
        )

        trailing()

        if (onBack != null) {
            // keeps the title centred when there is no trailing button
            Spacer(Modifier.width(4.dp))
        }
    }
}

@Composable
private fun PauseIcon() {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .width(10.dp)
                .height(34.dp)
                .background(Color.Black, RoundedCornerShape(3.dp))
        )
        Box(
            Modifier
                .width(10.dp)
                .height(34.dp)
                .background(Color.Black, RoundedCornerShape(3.dp))
        )
    }
}

@Composable
private fun TabLabel(label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            label,
            color = if (selected) Color.White else Color.Gray,
            fontSize = 20.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .width(56.dp)
                .height(3.dp)
                .background(
                    if (selected) peach else Color.Transparent,
                    RoundedCornerShape(2.dp)
                )
        )
    }
}

@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    hint: String? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 17.sp,
            modifier = Modifier.width(120.dp)
        )
        Column(Modifier.weight(1f)) {
            Slider(
                value = value,
                onValueChange = onChange,
                valueRange = range,
                steps = steps,
                colors = SliderDefaults.colors(
                    thumbColor = peach,
                    activeTrackColor = peach,
                    inactiveTrackColor = Color(0x33FFFFFF)
                )
            )
            if (hint != null) {
                Text(
                    hint,
                    color = Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    sub: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 17.sp)
            if (sub != null) {
                Text(sub, color = Color.Gray, fontSize = 13.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = peach,
                checkedBorderColor = peach,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF1E1F28),
                uncheckedBorderColor = Color.White
            )
        )
    }
}

@Composable
private fun SwatchRow(
    colors: List<Color>,
    selected: Int,
    onPick: (Int) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        colors.forEachIndexed { i, c ->
            Box(
                Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(c)
                    .clickable { onPick(i) },
                contentAlignment = Alignment.Center
            ) {
                if (i == selected) {
                    Text(
                        "✓",
                        color = if (c == Color.White || c == Color(0xFFE0E0E0) ||
                            c == Color(0xFFF9E04B) || c == Color(0xFFF2DF40)
                        ) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}
