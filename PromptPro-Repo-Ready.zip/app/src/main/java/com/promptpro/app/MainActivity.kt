package com.promptpro.app

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Recording
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.CameraController
import androidx.camera.view.LifecycleCameraController
import androidx.camera.view.PreviewView
import androidx.camera.view.video.AudioConfig
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.sqrt

private val peach = Color(0xFFFFCC99)
private val barGray = Color(0xFF2C2C2C)
private val sheetColor = Color(0xFF282A36)
private val cardColor = Color(0xFF1C1C1E)

private val fontColors = listOf(
    Color.White,
    Color(0xFFE0E0E0),
    Color(0xFF9E9E9E),
    Color(0xFFFF5252),
    Color(0xFFF9E04B),
    Color(0xFF6FCF3F),
    Color(0xFF4A90FF)
)

private val bgColors = listOf(
    Color.Black,
    Color(0xFF3A50E0),
    Color(0xFF4A90FF),
    Color(0xFF6FCF3F),
    Color(0xFFF2DF40),
    Color(0xFFD13DC1),
    Color(0xFFFF5252)
)

class MainActivity : ComponentActivity() {

    private val perms =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = peach,
                    background = Color.Black,
                    surface = cardColor,
                    onSurface = Color.White,
                    onBackground = Color.White
                )
            ) {
                PromptPro {
                    perms.launch(
                        arrayOf(
                            Manifest.permission.CAMERA,
                            Manifest.permission.RECORD_AUDIO
                        )
                    )
                }
            }
        }
    }
}

private fun displayName(c: Context, uri: Uri): String {
    var name = "Imported script.txt"
    c.contentResolver.query(uri, null, null, null, null)?.use { cur ->
        val i = cur.getColumnIndex(OpenableColumns.DISPLAY_NAME)
        if (i >= 0 && cur.moveToFirst()) {
            name = cur.getString(i) ?: name
        }
    }
    return name
}

private fun extractText(c: Context, uri: Uri, ext: String): String {
    return when (ext) {
        "docx" -> docxText(c, uri)
        "pdf" -> pdfText(c, uri)
        else -> c.contentResolver.openInputStream(uri)!!
            .bufferedReader().use { it.readText() }
    }
}

private fun docxText(c: Context, uri: Uri): String {
    c.contentResolver.openInputStream(uri)!!.use { ins ->
        java.util.zip.ZipInputStream(ins).use { zip ->
            var e = zip.nextEntry
            while (e != null) {
                if (e.name == "word/document.xml") {
                    val xml = zip.readBytes().toString(Charsets.UTF_8)
                    return xmlToText(xml)
                }
                e = zip.nextEntry
            }
        }
    }
    return ""
}

private fun xmlToText(xml: String): String {
    return xml
        .replace("</w:p>", "\n")
        .replace(Regex("<w:br[^>]*/>"), "\n")
        .replace(Regex("<w:tab[^>]*/>"), "\t")
        .replace(Regex("<[^>]+>"), "")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&quot;", "\"")
        .replace("&apos;", "'")
        .replace("&amp;", "&")
        .replace(Regex("\n{3,}"), "\n\n")
        .trim()
}

private fun pdfText(c: Context, uri: Uri): String {
    com.tom_roush.pdfbox.android.PDFBoxResourceLoader.init(c.applicationContext)
    return c.contentResolver.openInputStream(uri)!!.use { ins ->
        com.tom_roush.pdfbox.pdmodel.PDDocument.load(ins).use { doc ->
            com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc)
        }
    }.trim()
}

private fun granted(c: Context, p: String): Boolean {
    return ContextCompat.checkSelfPermission(
        c, p
    ) == PackageManager.PERMISSION_GRANTED
}

private fun readScripts(c: Context): LinkedHashMap<String, String> {

    val raw = c.getSharedPreferences("pp", 0)
        .getString("scripts", null)
        ?: return linkedMapOf(
            "My first script" to
                "Namaskar dosto! Apni script yahan likhein."
        )

    return try {
        val j = JSONObject(raw)
        LinkedHashMap<String, String>().apply {
            j.keys().forEach { k ->
                put(k, j.optString(k))
            }
        }
    } catch (_: Exception) {
        linkedMapOf("My first script" to "")
    }
}

private fun writeScripts(
    c: Context,
    m: Map<String, String>
) {
    val j = JSONObject()
    m.forEach { (k, v) -> j.put(k, v) }

    c.getSharedPreferences("pp", 0)
        .edit()
        .putString("scripts", j.toString())
        .apply()
}


@Composable
fun PromptPro(requestPermissions: () -> Unit) {

    val ctx = LocalContext.current
    val owner = LocalLifecycleOwner.current
    val view = LocalView.current
    val scope = rememberCoroutineScope()
    val prefs = remember { ctx.getSharedPreferences("pp", 0) }

    // Scripts

    var library by remember { mutableStateOf(readScripts(ctx)) }
    var selected by remember { mutableStateOf("") }
    var script by remember { mutableStateOf("") }

    // 0 = scripts list, 1 = teleprompter, 2 = editor
    var screen by remember { mutableIntStateOf(0) }

    // Settings (saved on the phone)

    var font by remember { mutableFloatStateOf(prefs.getFloat("font", 36f)) }
    var speed by remember { mutableFloatStateOf(prefs.getFloat("speed", 326f)) }
    var autoPause by remember { mutableStateOf(prefs.getBoolean("autoPause", false)) }
    var fontColorIdx by remember { mutableIntStateOf(prefs.getInt("fontColor", 0)) }
    var mirror by remember { mutableStateOf(prefs.getBoolean("mirror", false)) }
    var margin by remember { mutableFloatStateOf(prefs.getFloat("margin", 24f)) }
    var playDelay by remember { mutableFloatStateOf(prefs.getFloat("delay", 0f)) }
    var cycle by remember { mutableStateOf(prefs.getBoolean("cycle", false)) }
    var bgIdx by remember { mutableIntStateOf(prefs.getInt("bg", 0)) }
    var sensitivity by remember { mutableFloatStateOf(prefs.getFloat("sens", 0.55f)) }

    LaunchedEffect(
        font, speed, autoPause, fontColorIdx, mirror,
        margin, playDelay, cycle, bgIdx, sensitivity
    ) {
        prefs.edit()
            .putFloat("font", font)
            .putFloat("speed", speed)
            .putBoolean("autoPause", autoPause)
            .putInt("fontColor", fontColorIdx)
            .putBoolean("mirror", mirror)
            .putFloat("margin", margin)
            .putFloat("delay", playDelay)
            .putBoolean("cycle", cycle)
            .putInt("bg", bgIdx)
            .putFloat("sens", sensitivity)
            .apply()
    }

    // Teleprompter state

    var running by remember { mutableStateOf(false) }
    var voice by remember { mutableStateOf(false) }
    var micInfo by remember { mutableStateOf("") }
    var countdown by remember { mutableIntStateOf(0) }
    var textHeightPx by remember { mutableIntStateOf(0) }
    var showSettings by remember { mutableStateOf(false) }
    var tab by remember { mutableIntStateOf(0) }
    var showNew by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    // Camera state

    var cameraOn by remember { mutableStateOf(false) }
    var front by remember { mutableStateOf(true) }
    var recording by remember { mutableStateOf(false) }
    var activeRecording by remember { mutableStateOf<Recording?>(null) }

    val scroll = rememberScrollState()

    val cam = remember(ctx) {
        LifecycleCameraController(ctx).apply {
            setEnabledUseCases(CameraController.VIDEO_CAPTURE)
            cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
        }
    }

    DisposableEffect(cam, owner, cameraOn, screen) {
        if (
            cameraOn && screen == 1 &&
            granted(ctx, Manifest.permission.CAMERA)
        ) {
            try {
                cam.bindToLifecycle(owner)
            } catch (_: Throwable) {
            }
        }
        onDispose {
            activeRecording?.stop()
            try {
                cam.unbind()
            } catch (_: Throwable) {
            }
        }
    }

    DisposableEffect(screen) {
        view.keepScreenOn = screen == 1
        onDispose { view.keepScreenOn = false }
    }

    // Helper functions

    fun saveCurrent() {
        if (selected.isNotEmpty()) {
            library = LinkedHashMap(library).apply {
                put(selected, script)
            }
            writeScripts(ctx, library)
        }
    }

    fun openScript(name: String) {
        selected = name
        script = library[name] ?: ""
        running = false
        voice = false
        countdown = 0
        showSettings = false
        scope.launch { scroll.scrollTo(0) }
        screen = 1
    }

    fun leaveReader() {
        running = false
        voice = false
        countdown = 0
        activeRecording?.stop()
        cameraOn = false
        showSettings = false
        screen = 0
    }

    fun onPlay() {
        if (running) {
            running = false
            return
        }
        if (countdown > 0) return

        if (
            autoPause &&
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            requestPermissions()
            return
        }

        val d = playDelay.toInt()

        scope.launch {
            if (scroll.maxValue > 0 && scroll.value >= scroll.maxValue - 1) {
                scroll.scrollTo(0)
            }
            if (d > 0) {
                var i = d
                while (i > 0) {
                    countdown = i
                    delay(1000)
                    i--
                }
                countdown = 0
            }
            running = true
        }
    }

    fun toggleRecording() {

        if (
            !granted(ctx, Manifest.permission.CAMERA) ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            requestPermissions()
            return
        }

        if (recording) {
            activeRecording?.stop()
            return
        }

        val stamp = SimpleDateFormat(
            "yyyyMMdd_HHmmss",
            Locale.US
        ).format(Date())

        val values = ContentValues().apply {
            put(
                MediaStore.Video.Media.DISPLAY_NAME,
                "PromptPro_$stamp.mp4"
            )
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(
                MediaStore.Video.Media.RELATIVE_PATH,
                "Movies/PromptPro"
            )
        }

        val output = MediaStoreOutputOptions.Builder(
            ctx.contentResolver,
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        )
            .setContentValues(values)
            .build()

        try {

            activeRecording = cam.startRecording(
                output,
                AudioConfig.create(true),
                ContextCompat.getMainExecutor(ctx)
            ) { event: VideoRecordEvent ->

                when (event) {

                    is VideoRecordEvent.Start -> {
                        recording = true
                    }

                    is VideoRecordEvent.Finalize -> {
                        recording = false
                        activeRecording = null

                        val msg =
                            if (event.hasError())
                                "Recording failed"
                            else
                                "Saved to Gallery / Movies / PromptPro"

                        Toast.makeText(
                            ctx, msg, Toast.LENGTH_LONG
                        ).show()
                    }

                    else -> {}
                }
            }

        } catch (e: Exception) {
            Toast.makeText(
                ctx,
                "Cannot start recording: ${e.localizedMessage}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    // File import (PDF / DOCX / TXT)

    val importLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            scope.launch {
                val name = withContext(Dispatchers.IO) {
                    displayName(ctx, uri)
                }
                val ext = name.substringAfterLast('.', "")
                    .lowercase(Locale.ROOT)

                if (ext != "pdf" && ext != "docx" && ext != "txt") {
                    Toast.makeText(
                        ctx, "Sirf PDF, DOCX ya TXT file chuno",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        ctx, "Importing...", Toast.LENGTH_SHORT
                    ).show()

                    val text = withContext(Dispatchers.IO) {
                        try {
                            extractText(ctx, uri, ext)
                        } catch (e: Throwable) {
                            null
                        }
                    }

                    if (text == null) {
                        Toast.makeText(
                            ctx, "File padh nahi paya",
                            Toast.LENGTH_LONG
                        ).show()
                    } else if (text.isBlank()) {
                        Toast.makeText(
                            ctx,
                            "File me text nahi mila (scanned PDF ho sakti hai)",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        saveCurrent()
                        val base = name.substringBeforeLast('.')
                            .ifBlank { "Imported" }
                        var key = base
                        var n = 2
                        while (library.containsKey(key)) {
                            key = "$base ($n)"
                            n++
                        }
                        library = LinkedHashMap(library).apply {
                            put(key, text)
                        }
                        writeScripts(ctx, library)
                        openScript(key)
                        Toast.makeText(
                            ctx, "Imported: $key", Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }
        }
    }

    BackHandler(enabled = screen != 0 || showSettings) {
        if (showSettings) {
            showSettings = false
        } else if (screen == 2) {
            saveCurrent()
            screen = 1
        } else {
            leaveReader()
        }
    }

    // Voice detection (Auto Pause): scrolls only while you are talking

    LaunchedEffect(running, autoPause, sensitivity, screen) {

        if (
            !running ||
            !autoPause ||
            screen != 1 ||
            !granted(ctx, Manifest.permission.RECORD_AUDIO)
        ) {
            voice = false
            micInfo = ""
            return@LaunchedEffect
        }

        withContext(Dispatchers.IO) {

            var rec: AudioRecord? = null

            try {

                val rate = 16000

                val size = AudioRecord.getMinBufferSize(
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                ).coerceAtLeast(2048)

                val r = AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    rate,
                    AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT,
                    size * 2
                )
                rec = r

                if (r.state != AudioRecord.STATE_INITIALIZED) {
                    micInfo = "Mic nahi mila - Auto Pause band"
                    voice = true
                    return@withContext
                }

                val buf = ShortArray(1024)
                var floor = -60.0
                var last = 0L
                var lastShown = 0L

                r.startRecording()

                if (r.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                    micInfo = "Mic start nahi hua - Auto Pause band"
                    voice = true
                    return@withContext
                }

                while (isActive && running) {

                    val n = r.read(buf, 0, buf.size)

                    if (n <= 0) {
                        micInfo = "Mic read error ($n)"
                        delay(50)
                        continue
                    }

                    var sum = 0.0

                    for (i in 0 until n) {
                        val x = buf[i].toDouble() / 32768.0
                        sum += x * x
                    }

                    val db = 20 * log10(
                        sqrt(sum / n).coerceAtLeast(.000001)
                    )

                    val threshold = maxOf(
                        -52.0 + (1 - sensitivity.toDouble()) * 10,
                        floor + 8 + (1 - sensitivity.toDouble()) * 6
                    )

                    val now = System.currentTimeMillis()

                    if (db > threshold) {
                        last = now
                        voice = true
                    } else {
                        floor = floor * .96 + db * .04

                        if (now - last >= 1500) {
                            voice = false
                        }
                    }

                    if (now - lastShown > 300) {
                        lastShown = now
                        micInfo =
                            "Mic ${db.toInt()} dB / need ${threshold.toInt()} dB"
                    }

                    delay(20)
                }

            } catch (e: Throwable) {
                if (e is java.util.concurrent.CancellationException) throw e
                micInfo = "Mic error: ${e.localizedMessage}"
                voice = true
            } finally {
                try {
                    rec?.stop()
                } catch (_: Throwable) {
                }
                try {
                    rec?.release()
                } catch (_: Throwable) {
                }
            }
        }
    }

    // Automatic scrolling (speed is in characters per minute)

    LaunchedEffect(running, voice, autoPause, speed, textHeightPx, cycle) {

        val pxPerChar = textHeightPx.toFloat() / max(1, script.length)
        var prev = 0L

        while (isActive && running) {

            val t = withFrameNanos { it }

            if (prev != 0L && (!autoPause || voice)) {

                val dt = ((t - prev) / 1_000_000_000f).coerceAtMost(0.05f)

                scroll.scrollBy(speed / 60f * pxPerChar * dt)

                if (
                    scroll.maxValue > 0 &&
                    scroll.value >= scroll.maxValue - 1
                ) {
                    if (cycle) {
                        scroll.scrollTo(0)
                    } else {
                        running = false
                    }
                }
            }

            prev = t
        }
    }

    // Screens

    val bgColor = bgColors[bgIdx.coerceIn(0, bgColors.size - 1)]
    val textColor = fontColors[fontColorIdx.coerceIn(0, fontColors.size - 1)]

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .windowInsetsPadding(WindowInsets.systemBars)
    ) {

        if (screen == 0) {

            // ---------- Scripts list ----------

            Column(Modifier.fillMaxSize()) {

                TopBar(title = "PromptPro  v2.0", onBack = null) {}

                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    if (library.isEmpty()) {
                        Text(
                            "Abhi koi script nahi hai. Neeche + NEW SCRIPT dabao ya file import karo.",
                            color = Color.Gray
                        )
                    }

                    library.forEach { (name, body) ->

                        Surface(
                            color = cardColor,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { openScript(name) }
                        ) {
                            Row(
                                Modifier.padding(
                                    start = 16.dp,
                                    top = 8.dp,
                                    bottom = 8.dp,
                                    end = 4.dp
                                ),
                                verticalAlignment = Alignment.CenterVertically
                            ) {

                                Column(Modifier.weight(1f)) {
                                    Text(
                                        name,
                                        color = Color.White,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Text(
                                        "${body.length} characters",
                                        color = Color.Gray,
                                        fontSize = 12.sp
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        library = LinkedHashMap(library).apply {
                                            remove(name)
                                        }
                                        writeScripts(ctx, library)
                                    }
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Delete",
                                        tint = Color(0xFFFF6B6B)
                                    )
                                }
                            }
                        }
                    }
                }

                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {

                    Button(
                        onClick = {
                            newName = ""
                            showNew = true
                        },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = peach,
                            contentColor = Color.Black
                        )
                    ) {
                        Text("+ NEW SCRIPT")
                    }

                    OutlinedButton(
                        onClick = { importLauncher.launch(arrayOf("*/*")) },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("IMPORT FILE", color = peach)
                    }
                }
            }

        } else if (screen == 2) {

            // ---------- Script editor ----------

            Column(
                Modifier
                    .fillMaxSize()
                    .imePadding()
            ) {

                TopBar(
                    title = selected,
                    onBack = {
                        saveCurrent()
                        screen = 1
                    }
                ) {
                    IconButton(
                        onClick = {
                            saveCurrent()
                            Toast.makeText(
                                ctx, "Script saved", Toast.LENGTH_SHORT
                            ).show()
                        }
                    ) {
                        Icon(
                            Icons.Default.Check,
                            contentDescription = "Save",
                            tint = peach
                        )
                    }
                }

                BasicTextField(
                    value = script,
                    onValueChange = { script = it },
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(16.dp),
                    textStyle = TextStyle(
                        color = Color.White,
                        fontSize = 20.sp,
                        lineHeight = 30.sp
                    ),
                    cursorBrush = SolidColor(peach)
                )
            }

        } else {

            // ---------- Teleprompter (Classic Mode) ----------

            Column(Modifier.fillMaxSize()) {

                TopBar(
                    title = "Classic Mode",
                    onBack = { leaveReader() }
                ) {
                    IconButton(
                        onClick = {
                            running = false
                            saveCurrent()
                            screen = 2
                        }
                    ) {
                        Icon(
                            Icons.Default.Edit,
                            contentDescription = "Edit",
                            tint = Color.White
                        )
                    }
                }

                BoxWithConstraints(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .background(bgColor)
                ) {

                    val h = maxHeight

                    if (cameraOn && granted(ctx, Manifest.permission.CAMERA)) {
                        AndroidView(
                            factory = {
                                PreviewView(it).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                    controller = cam
                                }
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    Column(
                        Modifier
                            .fillMaxSize()
                            .graphicsLayer {
                                scaleX = if (mirror) -1f else 1f
                            }
                            .verticalScroll(scroll)
                    ) {

                        Spacer(Modifier.height(h * 0.48f))

                        Text(
                            script,
                            color = textColor,
                            fontSize = font.sp,
                            lineHeight = (font * 1.45f).sp,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = margin.dp),
                            onTextLayout = {
                                textHeightPx = it.size.height
                            }
                        )

                        Spacer(Modifier.height(h * 0.52f))
                    }

                    // Reading line

                    Box(
                        Modifier
                            .offset(y = h * 0.48f)
                            .fillMaxWidth()
                            .height(2.dp)
                            .background(peach)
                    )

                    Box(
                        Modifier
                            .offset(y = h * 0.48f - 21.dp)
                            .width(26.dp)
                            .height(42.dp)
                            .background(
                                peach,
                                RoundedCornerShape(
                                    topEnd = 8.dp,
                                    bottomEnd = 8.dp
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("▶", color = Color.Black, fontSize = 12.sp)
                    }

                    if (countdown > 0) {
                        Text(
                            countdown.toString(),
                            color = peach,
                            fontSize = 96.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.align(Alignment.Center)
                        )
                    }

                    if (autoPause && running && micInfo.isNotEmpty()) {
                        Text(
                            micInfo,
                            color = peach,
                            fontSize = 11.sp,
                            modifier = Modifier
                                .align(Alignment.TopStart)
                                .padding(8.dp)
                        )
                    }

                    if (cameraOn) {
                        Row(
                            Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {

                            Button(
                                onClick = {
                                    front = !front
                                    cam.cameraSelector =
                                        if (front)
                                            CameraSelector.DEFAULT_FRONT_CAMERA
                                        else
                                            CameraSelector.DEFAULT_BACK_CAMERA
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0x99000000),
                                    contentColor = Color.White
                                )
                            ) {
                                Text(if (front) "FRONT" else "BACK")
                            }

                            Button(
                                onClick = { toggleRecording() },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor =
                                        if (recording) Color.Red else peach,
                                    contentColor = Color.Black
                                )
                            ) {
                                Text(if (recording) "STOP REC" else "REC")
                            }
                        }
                    }
                }

                // Bottom controls

                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(Color.Black)
                        .padding(horizontal = 12.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {

                    IconButton(
                        onClick = {
                            if (!cameraOn) {
                                if (!granted(ctx, Manifest.permission.CAMERA)) {
                                    requestPermissions()
                                } else {
                                    cameraOn = true
                                }
                            } else {
                                activeRecording?.stop()
                                cameraOn = false
                            }
                        }
                    ) {
                        Text(
                            "🎥",
                            fontSize = 26.sp,
                            color = if (cameraOn) peach else Color.White
                        )
                    }

                    Box(
                        Modifier
                            .size(84.dp)
                            .clip(CircleShape)
                            .background(peach)
                            .clickable { onPlay() },
                        contentAlignment = Alignment.Center
                    ) {
                        if (running || countdown > 0) {
                            PauseIcon()
                        } else {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = "Play",
                                tint = Color.Black,
                                modifier = Modifier.size(48.dp)
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            running = false
                            voice = false
                            countdown = 0
                            scope.launch { scroll.scrollTo(0) }
                        }
                    ) {
                        Icon(
                            Icons.Default.Refresh,
                            contentDescription = "Reset",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = {
                            tab = 0
                            showSettings = true
                        }
                    ) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = "Settings",
                            tint = Color.White
                        )
                    }
                }
            }

            // ---------- Settings sheet ----------

            if (showSettings) {

                val secs = (script.length / max(speed, 1f) * 60f).toInt()

                Column(
                    Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .background(
                            sheetColor,
                            RoundedCornerShape(
                                topStart = 24.dp,
                                topEnd = 24.dp
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Estimated recording time: ${secs / 60} min ${secs % 60} sec",
                            color = Color.Gray,
                            fontSize = 14.sp,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { showSettings = false }) {
                            Icon(
                                Icons.Default.Close,
                                contentDescription = "Close",
                                tint = Color.Gray
                            )
                        }
                    }

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        TabLabel("General", tab == 0) { tab = 0 }
                        TabLabel("More", tab == 1) { tab = 1 }
                    }

                    Column(
                        Modifier
                            .heightIn(max = 400.dp)
                            .verticalScroll(rememberScrollState())
                    ) {

                        if (tab == 0) {

                            SettingSlider(
                                "Font Size", font, { font = it }, 20f..64f
                            )

                            SettingSlider(
                                "Scroll Speed", speed, { speed = it }, 60f..900f,
                                hint = "${speed.toInt()} characters/min"
                            )

                            SettingSwitch(
                                "Auto Pause",
                                "Pause automatically when no talking",
                                autoPause
                            ) {
                                autoPause = it
                                if (it && !granted(ctx, Manifest.permission.RECORD_AUDIO)) {
                                    requestPermissions()
                                }
                            }

                            Text(
                                "Font Color",
                                color = Color.White,
                                fontSize = 17.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
                            )
                            SwatchRow(fontColors, fontColorIdx) { fontColorIdx = it }

                            SettingSwitch(
                                "Mirror Mode",
                                "Use with teleprompter rig",
                                mirror
                            ) { mirror = it }

                        } else {

                            SettingSlider(
                                "Margins", margin, { margin = it }, 0f..60f
                            )

                            SettingSlider(
                                "Play Delay", playDelay, { playDelay = it },
                                0f..5f, steps = 4,
                                hint = "${playDelay.toInt()} sec"
                            )

                            SettingSwitch(
                                "Cycle Scrolling", null, cycle
                            ) { cycle = it }

                            SettingSlider(
                                "Mic Sensitivity", sensitivity,
                                { sensitivity = it }, 0f..1f,
                                hint = "Auto Pause ke liye"
                            )

                            Text(
                                "Background",
                                color = Color.White,
                                fontSize = 17.sp,
                                modifier = Modifier.padding(top = 8.dp, bottom = 6.dp)
                            )
                            SwatchRow(bgColors, bgIdx) { bgIdx = it }
                        }

                        Spacer(Modifier.height(12.dp))
                    }
                }
            }
        }
    }

    // New script dialog

    if (showNew) {
        AlertDialog(
            onDismissRequest = { showNew = false },
            title = { Text("New script") },
            text = {
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    singleLine = true,
                    label = { Text("Script name") }
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        val n = newName.trim()
                        if (n.isEmpty()) {
                            // nothing
                        } else if (library.containsKey(n)) {
                            Toast.makeText(
                                ctx,
                                "Is naam ki script pehle se hai",
                                Toast.LENGTH_SHORT
                            ).show()
                        } else {
                            saveCurrent()
                            library = LinkedHashMap(library).apply {
                                put(n, "")
                            }
                            writeScripts(ctx, library)
                            selected = n
                            script = ""
                            running = false
                            showNew = false
                            screen = 2
                        }
                    }
                ) {
                    Text("ADD", color = peach)
                }
            },
            dismissButton = {
                TextButton(onClick = { showNew = false }) {
                    Text("CANCEL")
                }
            }
        )
    }
}


@Composable
private fun TopBar(
    title: String,
    onBack: (() -> Unit)?,
    trailing: @Composable () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .height(60.dp)
            .background(barGray)
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {

        if (onBack != null) {
            IconButton(onClick = onBack) {
                Icon(
                    Icons.AutoMirrored.Filled.ArrowBack,
                    contentDescription = "Back",
                    tint = Color.White
                )
            }
        } else {
            Spacer(Modifier.width(12.dp))
        }

        Text(
            title,
            color = Color.White,
            fontSize = 20.sp,
            maxLines = 1,
            textAlign =
                if (onBack != null) TextAlign.Center else TextAlign.Start,
            modifier = Modifier.weight(1f)
        )

        trailing()

        if (onBack != null) {
            // keeps the title centred when there is no trailing button
            Spacer(Modifier.width(4.dp))
        }
    }
}

@Composable
private fun PauseIcon() {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(
            Modifier
                .width(10.dp)
                .height(34.dp)
                .background(Color.Black, RoundedCornerShape(3.dp))
        )
        Box(
            Modifier
                .width(10.dp)
                .height(34.dp)
                .background(Color.Black, RoundedCornerShape(3.dp))
        )
    }
}

@Composable
private fun TabLabel(label: String, selected: Boolean, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            label,
            color = if (selected) Color.White else Color.Gray,
            fontSize = 20.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
        )
        Spacer(Modifier.height(4.dp))
        Box(
            Modifier
                .width(56.dp)
                .height(3.dp)
                .background(
                    if (selected) peach else Color.Transparent,
                    RoundedCornerShape(2.dp)
                )
        )
    }
}

@Composable
private fun SettingSlider(
    label: String,
    value: Float,
    onChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    steps: Int = 0,
    hint: String? = null
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            label,
            color = Color.White,
            fontSize = 17.sp,
            modifier = Modifier.width(120.dp)
        )
        Column(Modifier.weight(1f)) {
            Slider(
                value = value,
                onValueChange = onChange,
                valueRange = range,
                steps = steps,
                colors = SliderDefaults.colors(
                    thumbColor = peach,
                    activeTrackColor = peach,
                    inactiveTrackColor = Color(0x33FFFFFF)
                )
            )
            if (hint != null) {
                Text(
                    hint,
                    color = Color.Gray,
                    fontSize = 13.sp,
                    modifier = Modifier.align(Alignment.End)
                )
            }
        }
    }
}

@Composable
private fun SettingSwitch(
    label: String,
    sub: String?,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 17.sp)
            if (sub != null) {
                Text(sub, color = Color.Gray, fontSize = 13.sp)
            }
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = peach,
                checkedBorderColor = peach,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color(0xFF1E1F28),
                uncheckedBorderColor = Color.White
            )
        )
    }
}

@Composable
private fun SwatchRow(
    colors: List<Color>,
    selected: Int,
    onPick: (Int) -> Unit
) {
    Row(
        Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        colors.forEachIndexed { i, c ->
            Box(
                Modifier
                    .weight(1f)
                    .height(40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(c)
                    .clickable { onPick(i) },
                contentAlignment = Alignment.Center
            ) {
                if (i == selected) {
                    Text(
                        "✓",
                        color = if (c == Color.White || c == Color(0xFFE0E0E0) ||
                            c == Color(0xFFF9E04B) || c == Color(0xFFF2DF40)
                        ) Color.Black else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }
        }
    }
}
